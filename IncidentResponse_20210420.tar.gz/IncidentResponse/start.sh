#!/bin/bash


#竹林再遇北极熊制作于2019年8月10日，今晚真的很像士兵许三多一样难过，在连长(老大)都走了以后，1个人守着1个人的连队(小组)，想起钢七连"不抛弃，不放弃"的精神，希望这种事不会再经历，真难熬


#v1.0 建立
#v1.1 优化


#原则：不运行、不自启即使是威胁其影响也是微乎其微的
#作用：好记性不如烂笔头，自动化收集操作系统中的现象、持久化、痕迹，并将无用信息进行过滤，方便检查,即只做信息收集不做过多判断；例如快速获取某个程序的启动方式
#翻译：百度翻译
#指南：使用root权限在当前目录下运行start.sh，根据提示输入服务器ip，检查记录存档于当前文件夹的【$HostIp_$SystemDate-results/*】目录下


#第三方工具，可自行至源站下载、编译、替换
  #1 busybox  防止系统命令被替换以及脚本兼容性
    #下载
      #https://busybox.net/downloads/busybox-1.32.1.tar.bz2
    #编译
      #make defconfig
      #make CROSS_COMPILE=""

  #2 chkrootkit  rootkit检查工具
    #下载
      #ftp://ftp.pangeia.com.br/pub/seg/pac/chkrootkit.tar.gz
    #编译
      #make sense
      #yum -y install glibc-static 如果报"/usr/bin/ld：找不到 -lc"错误时

  #3 hm  webshell查杀工具
    #下载
      #http://dl.shellpub.com/hm/latest/hm-linux-amd64.tgz?version=1.8.2


#异常文件删除方法
  #加锁
    #chattr -i test.sh && ./rm -rf test.sh
  #隐藏空格，转义符，连接符，显示名称乱码
    #执行命令ls -li获取该文件的inode，find . -type f -inum inodeNumber -delete


#检查内容
  #0 创建检查目录和输出文档
  #1 现象检查
    #  1.1 已监听端口
    #  1.2 已建立连接
    #  1.3 系统进程
  #2 持久化检查
    #  2.1 任务计划
    #  2.2 环境变量
    #  2.3 系统服务
    #  2.4 账户权限
    #  2.5 rootkit
  #3 痕迹检查
    #  3.1 登陆日志
    #  3.2 文件落地
    #  3.3 历史命令
    #  3.4 防火墙
    #  3.5 杀毒软件(手动检查)


#在可读文件中进行匹配的敏感词库，可自行更新
  #可能的启动方式
    #/end
    #. end
    #./end
    #sh/nohup/fork/exec等 /end

  #匹配每行第一个/，每行第一个.空格，每行第一个./,每行第一个[A-Za-z0-9/_.- ]空格/
    #^/|^\.\s+|^\./|^[A-Za-z0-9/_\.\-]+\s+/|

  #1-n个空格/，1-n个空格.空格，1-n个空格./，1-n个空格[A-Za-z0-9/_.- ]空格/
    #\s+/|\s+\.\s+|\s+\./|\s+[A-Za-z0-9/_\.\-]+\s+/|

  #[|、||、&、&&]1-n个空格[A-Za-z0-9/_.-]
    #[|&]+\s+[A-Za-z0-9\s+/_\.\-]+
                       #第一个条件不生效
GetStartType=' grep -E "asdfasdf|curl|wget|nohup|^alias\s|LD_PRELOAD|Exec|^/|^\.\s+|^\./|^[A-Za-z0-9/_\.\-]+\s+/|\s+/|\s+\.\s+|\s+\./|\s+[A-Za-z0-9/_\.\-]+\s+/|[|&]+\s+[A-Za-z0-9\s+/_\.\-]+"'

by="`pwd`/busybox"

line="echo -e \n-------------------------------------------------\n-------------------------------------------------"

SystemDate=`date +"%Y-%m-%d"`




#0 创建检查目录和输出文档
read -ep "To create a check folder, please enter the host IP address(x.x.x.x): " HostIp


#收集合法的ip地址，如果不是则重新输入，如果是判断检查目录是否存在，如存在则结束循环，如果不存在创建后结束循环
for ((;;))
do
    IpMatch=`echo "$HostIp" | $by grep -E "^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$"`
    if [ "$IpMatch" = "" ] ; then
        read -ep "Format error, please re-enter the host IP address         (x.x.x.x): " HostIp
    else
	if [ -d $HostIp-$SystemDate-results ] ; then
            echo "Check directory created!"
            break
        else
            mkdir $HostIp-$SystemDate-results
            $line
            echo "Check that the folder was created successfully: [ $HostIp-$SystemDate-results ]"
            break
        fi
    fi
done


ir="tee -a $HostIp-$SystemDate-results/0-Summary_results.txt"

FileResult="$HostIp-$SystemDate-results/1-FileSumInfoResult.txt"

Temp="$HostIp-$SystemDate-results/Temp.txt"

Temp2="$HostIp-$SystemDate-results/Temp2.txt"

#busybox没有file命令
FileCmd=`which file`



#收集文件综合信息
GetFileSum(){

    #排序去重
    FileSumSort=`$by cat $Temp2 | $by grep -vE "^\$" | $by sort | $by uniq`
   
 
    #循环收集
    FileSumLine=`echo "$FileSumSort" | wc -l`
    for ((i=1; i<=$FileSumLine; i++))
    do
        FileSumName=`echo "$FileSumSort" | $by awk 'NR=='$i' {print}'`
        if [ -f $FileSumName ] ; then
            FileAccessTime=`$by stat $FileSumName | $by tail -n 3 | $by grep "Access" | $by awk -F "." '{print $1}'`
            FileModifyTime=`$by stat $FileSumName | $by tail -n 3 | $by grep "Modify" | $by awk -F "." '{print $1}'`
            FileChangeTime=`$by stat $FileSumName | $by tail -n 3 | $by grep "Change" | $by awk -F "." '{print $1}'`
            FileMd5=`$by md5sum $FileSumName | $by awk '{print $1}'`

            #将各信息输出至文件
            FileSumEcho1=`echo -e "[$FileSumName]"        >> $FileResult`
            FileSumEcho2=`echo -e "  FileType: $FileType" >> $FileResult`
            FileSumEcho3=`echo -e "   FileMd5:$FileMd5"   >> $FileResult`
            FileSumEcho4=`echo -e "    $FileAccessTime"   >> $FileResult`
            FileSumEcho5=`echo -e "    $FileModifyTime"   >> $FileResult`
            FileSumEcho6=`echo -e "    $FileChangeTime"   >> $FileResult`
            FileSumEcho7=`echo -e ""                      >> $FileResult`
        fi
    done    

    
    #删除临时文件
    if [ -f $Temp2 ] ; then
        $by rm -rf $Temp2
    fi
}


#收集文件类型，并对可读文件进行信息收集
GetFileType(){
    if [[ "$FileType" =~ "shell" ]] ; then
        LineSave=`$line | $ir`
        ShellEcho=`echo "                                          [shell] [$GetFilePathEcho]" | $ir`
        Shell=`$by cat $GetFilePathEcho | $GetStartType | $by grep -vE "#|\s?for\s?|\s?if\s?"  | $ir`
        FileSum=`echo "$GetFilePathEcho" >> $Temp2`

    elif [[ "$FileType" =~ "Python" ]] ; then
        LineSave=`$line | $ir`
        PythonEcho=`echo "                                         [python] [$GetFilePathEcho]" | $ir`
        python=`$by cat $GetFilePathEcho | $GetStartType | $by grep -vE "#|\s?for\s?|\s?if\s?"  | $ir`
        FileSum=`echo "$GetFilePathEcho" >> $Temp2`

    elif [[ "$FileType" =~ "cannot open" ]] ; then
        #LineSave=`$line | $ir`
        NotExistEcho=`echo "                                      [not exist] [$GetFilePathEcho]" | $ir`

    elif [[ "$FileType" =~ "directory" ]] ; then
        LineSave=`$line | $ir`
        DirectoryEcho=`echo "                                      [directory] [$GetFilePathEcho]" | $ir`
        DirExist=`$by ls $GetFilePathEcho\/* 2>/dev/null | $ir`

        #如果是目录则会再来一次GetFileType，作用于收集更深层次的目录例如$DirExist中的文件路径及其内容，并过滤无关信息
        DirExistLine=`echo "$DirExist" | wc -l`
        if [ "$DirExist" != "" ] ; then
            for ((b=1; b<=$DirExistLine; b++))
            do
                GetFilePathEcho=`echo "$DirExist" | $by awk 'NR=='$b' {print}'`
                FileType=`$FileCmd $GetFilePathEcho | $by awk -F ": " '{print $2}' | $by awk -F "," '{print $1}'`
                GetFileType
            done
        fi

    elif [[ "$FileType" =~ "ASCII text" ]] ; then
        LineSave=`$line | $ir`
        AsciiTextEcho=`echo "                                     [ascii text] [$GetFilePathEcho]" | $ir`
        ascii_text=`$by cat $GetFilePathEcho | $GetStartType | $by grep -vE "#|\s?for\s?|\s?if\s?"  | $ir`
        FileSum=`echo "$GetFilePathEcho" >> $Temp2`

    elif [[ "$FileType" =~ "ELF" ]] ; then
        #LineSave=`$line | $ir`
        ElfEcho=`echo "                                            [elf] [$GetFilePathEcho]" | $ir`

    elif [[ "$FileType" =~ "symbolic link" ]] ; then
        #LineSave=`$line | $ir`
        SymbolicLinkEcho=`echo "                                  [symbolic link] [$GetFilePathEcho]" | $ir`

    elif [[ "$FileType" =~ "empty" ]] ; then
        #LineSave=`$line | $ir`
        EmptyEcho=`echo "                                          [empty] [$GetFilePathEcho]" | $ir`

    else
        LineSave=`$line | $ir`
        echo "[$FileType] [$GetFilePathEcho]" | $ir
    fi
}


#收集文件内容
GetFileCon(){

#如果$FileName是文件，则进行信息收集，1级检查对象
if [ -f $FileName ] ; then
    FileExist=`$by cat $FileName | $GetStartType | $by grep -vE "#|\s?for\s?|\s?if\s?" | $ir` #过滤文件中的无关信息，形成1级检查对象结果

    #如果是任务计划文件，则第一列可能是*/1，因此将其过滤；只显示路径；将路径最后1个.替换为空；将路径最后一个/替换为空；先排序再去重，形成2级检查对象
    GetFilePath=`echo "$FileExist" | $by awk '{sub(/^.\/[0-9]/,""); print}' | $by grep -oE "/[A-Za-z0-9/\._-]+" | $by sed 's/\.$//' | $by sed 's/\/$//' | $by sort | $by uniq`

    #获取已检查过文件的路径
    FileSum=`echo "$GetFilePath" >> $Temp2`

    #过滤白名单中的路径后放入GetFileType
    FileLine=`echo "$GetFilePath" | wc -l`
    for ((i=1; i<=$FileLine; i++))
    do
        GetFilePathEcho=`echo "$GetFilePath" | $by awk 'NR=='$i' {print}'`

        #2级检查对象的白名单，例如1级检查对象：/etc/profile文件中有/usr/sbin类的目录，收集无意义；非第一检查对象白名单，而是从其他检查对象跳转检查时需要排除的路径，初次使用时建议根据实际情况更新白名单，防止收集过多无用信息。如果不检查2级对象则会遗漏过多信息，但是检查就得对部分对象加白
        ExcludePath=`echo "$GetFilePathEcho" | $by grep -oE "^asdfasdf|/bin|/boot|/dev|/etc|/home|/lib|/lib64|/media|/mnt|/opt|/proc|/root|/run|/sbin|/srv|/sys|/tmp|/usr|/var|/www|/usr/bin/id|/usr/sbin|/usr/local/sbin|/dev/null|/etc/profile.d|/etc/sysconfig/bash-prompt-xterm|/etc/sysconfig/bash-prompt-screen|/etc/sysconfig/bash-prompt-default|/.bashrc|/etc/bashrc|/etc/sysconfig/network|/sbin/ip|/etc/sysconfig/network-scripts|/etc/sysconfig/pcmcia|/network-functions|/|//|/etc/sysconfig/static-routes|/sbin/route|/bin/sleep|/usr|/var/lock/subsys/network|/etc/rc.d/rc.local|/usr/lib64|/opt/RecycleBin"` 
        if [[ $GetFilePathEcho = $ExcludePath ]] ; then
            continue
        else
            FileType=`$FileCmd $GetFilePathEcho | $by awk -F ": " '{print $2}' | $by awk -F "," '{print $1}'`  #只保留文件类型
            GetFileType
        fi
    done


#如果$FileName是目录，则进行信息收集，1级检查对象
elif [ -d $FileName ] ; then
    FileNameMore=`$by ls $FileName\/* 2>&1`
    FileSum=`echo "$GetFilePath" >> $Temp2`

    #收集$FileName中存在的路径形成1级检查对象，并过滤无关信息
    FileLine=`echo "$FileNameMore" | wc -l`
    for ((i=1; i<=$FileLine; i++))
    do
        FileExistSave=`echo "$FileNameMore" | $by awk 'NR=='$i' {print}'`
        LineSave=`$line | $ir`
        FileExistSaveEcho=`echo "      [$FileExistSave]" | $ir`

        #1级检查对象的结果如果为空则停止本次循环
        GetFileName=`cat $FileExistSave | $GetStartType | $by grep -vE "#|\s?for\s?|\s?if\s?" | $ir`
        if [ "$GetFileName" = "" ] ; then
            LineSave=`$line | $ir`
            continue

        #如果不为空则形成第2级检查对象，并对其进行检查
        else
            #如果是任务计划文件，则第一列可能是*/1，因此将其过滤；只显示路径；将路径最后1个.替换为空；将路径最后一个/替换为空；先排序再去重
            GetFilePath=`echo "$GetFileName" | $by awk '{sub(/^.\/[0-9]/,""); print}' | $by grep -oE "/[A-Za-z0-9/\._-]+"| $by sed 's/\.$//' | $by sed 's/\/$//' | $by sort | $by uniq`

            #收集2级检查对象的路径，过滤无关信息后将其放入GetFileType
            GetFilePathLine=`echo "$GetFilePath" | wc -l`
            for ((a=1; a<=$GetFilePathLine; a++))
            do
                GetFilePathEcho=`echo "$GetFilePath" | $by awk 'NR=='$a' {print}'`
                FileType=`$FileCmd $GetFilePathEcho | $by awk -F ": " '{print $2}' | $by awk -F "," '{print $1}'`
                GetFileType
            done
        fi
    done


#如果$FileName不存在，则返回不存在的信息
else
    FileNotExist=`echo "                                                 not exist" | $ir`
fi
}


#收集普通用户名和数量
UserHome=`$by ls -alt /home | $by grep -vE "\s\.$|\s\.\.$" | $by awk '{if (NR>1) print $NF}'`
UserHomeLine=`echo "$UserHome" | wc -l`


#对普通用户家目录下文件检查
GetUserFileCon(){
    for ((n=1; n<=$UserHomeLine; n++))
    do
        UserHomeName=`echo "$UserHome" | $by awk 'NR=='$n' {print}'`
        FileName=`echo "/home/$UserHomeName/$UserFile"`
        FileSum=`echo "$FileName" >> $Temp2`
        LineSave=`$line | $ir`
        echo "      [$FileName]" | $ir
        GetFileCon
    done
}


#只检查1级对象，不检查2级对象
CatFileCon(){
    if [ -f $FileName ] ; then
        CatFile=`$by cat $FileName | $ir`
        FileSum=`echo "$FileName" >> $Temp2`
    else
        FileNotExist=`echo "                                                 Not exist" | $ir`
    fi
}




#1 现象检查
#1.1 已监听端口
$line
echo "[1 Phenomenon inspection]" | $ir
echo "  [1.1 Monitored port]" | $ir
listen=`$by netstat -pantu | $by grep -E "Proto|LIST" | $ir`


#1.2 检查已建立连接
LineSave=`$line | $ir`
echo "  [1.2 Connection established]" | $ir
estab=`$by netstat -pantu | $by grep -E "Proto|EST" | $ir`


#1.3.1 收集系统进程的详细信息,busybox的ps不支持-Heo参数
LineSave=`$line | $ir`
echo "  [1.3-1 System process(ps)]" | $ir
PsCmd=`which ps`
if [ -f $PsCmd ] ; then
    SystemProcess=`$PsCmd -Heo user,pid,ppid,tty,%cpu,%mem,lstart,etime,cmd | $ir`
else
    echo "      [ps cmdline]: not exist" | $ir
    echo "        [$PsCmd]" | $ir
fi


#1.3.2 收集pid,ppid不为2的系统进程信息,使用busybox
LineSave=`$line | $ir`
echo "  [1.3-2 System process(busybox)]" | $ir
SystemProcessExecPath=`$by ps | $by awk -F " " '{$3=""; print}' | $by awk '{sub(/ /,"\t\t"); sub(/ /,"\t\t"); if (NR>1) print}' | $by grep -vE "\[.*\]$" | $ir`



#1.3.3 收集[/proc/数字/]目录下的exe信息
LineSave=`$line | $ir`
echo "  [1.3-3 System process(/proc/\$pid/exe)]" | $ir
ProcPidExe=`$by ls -alt /proc/*/exe 2>/dev/null | $by grep -v "/proc/self/exe" | $by grep " -> " | $ir`
FileSum=`echo "$ProcPidExe" | $by awk '{sub(/ \(deleted\)$/,""); print}' | $by awk '{print $NF}' >> $Temp2`



#2 持久化检查
$line | $ir
echo "[2 Persistence inspection]" | $ir
echo "  [2.1 Task plan check results]" | $ir
echo "    [2.1.1 /etc/crontab]" | $ir
FileName="/etc/crontab"
GetFileCon


LineSave=`$line | $ir`
echo "    [2.1.2 /var/spool/cron/*]" | $ir
DirLsSave=`$by ls -alt /var/spool/cron/* 2>/dev/null | $by awk '{print $NF}' | $ir`
FileName="/var/spool/cron"
GetFileCon


LineSave=`$line | $ir`
echo "    [2.1.3 /etc/cron.d/*]" | $ir
DirLsSave=`$by ls -alt /etc/cron.d/* 2>/dev/null | $by awk '{print $NF}' | $ir`
FileName="/etc/cron.d"
GetFileCon


LineSave=`$line | $ir`
echo "    [2.1.4 /etc/anacrontab]" | $ir
FileName="/etc/anacrontab"
GetFileCon



#2.2 环境变量检查
$line | $ir
echo "  [2.2 Environmental variable check]" | $ir
echo "    [2.2.1 /etc/profile]" | $ir
FileName="/etc/profile"
GetFileCon

#ld.so.preload文件检查
LineSave=`$line | $ir`
echo "      [/etc/ld.so.preload]" | $ir
FileName="/etc/ld.so.preload"
CatFileCon


#检查root账户和普通账户的/etc/bashrc
LineSave=`$line | $ir`
echo "    [2.2.2-1 /etc/bashrc]" | $ir
FileName="/etc/bashrc"
GetFileCon


#检查root账户和普通账户的/etc/bash.bashrc
LineSave=`$line | $ir`
echo "    [2.2.2-2 /etc/bash.bashrc]" | $ir
FileName="/etc/bash.bashrc"
GetFileCon


#检查root账户和普通账户的~/.profile
LineSave=`$line | $ir`
echo "    [2.2.3 ~/.profile]" | $ir

echo "      [/root/.profile]" | $ir
FileName="/root/.profile"
GetFileCon

UserFile=".profile"
GetUserFileCon


#检查root账户和普通账户的~/.bash_profile
LineSave=`$line | $ir`
echo "    [2.2.4 ~/.bash_profile]" | $ir

echo "      [/root/.bash_profile]" | $ir
FileName="/root/.bash_profile"
GetFileCon

UserFile=".bash_profile"
GetUserFileCon


#检查root账户和普通账户的~/.bashrc
LineSave=`$line | $ir`
echo "    [2.2.5 ~/.bashrc]" | $ir

echo "      [/root/.bashrc]" | $ir
FileName="/root/.bashrc"
GetFileCon

UserFile=".bashrc"
GetUserFileCon


#检查root账户和普通账户的~/.bash_login
LineSave=`$line | $ir`
echo "    [2.2.6 ~/.bash_login]" | $ir

echo "      [/root/.bash_login]" | $ir
FileName="/root/.bash_login"
GetFileCon

UserFile=".bash_login"
GetUserFileCon


#检查root账户和普通账户的~/.bash_logout
LineSave=`$line | $ir`
echo "    [2.2.7 ~/.bash_logout]" | $ir

echo "      [/root/.bash_logout]" | $ir
FileName="/root/.bash_logout"
GetFileCon

UserFile=".bash_logout"
GetUserFileCon




$line
#2.3 系统服务
LineSave=`$line | $ir`
echo "  [2.3 System service check]" | $ir
echo "    [2.3.1 Init]" | $ir


#收集当前的启动级别和确认chkconfig执行路径
RunLevel=`$by runlevel | $by awk '{print $2}'`
echo "               [Runlevel]: $RunLevel" | $ir
ChkCmd=`which chkconfig`
echo "      [chkconfig cmdline]: $ChkCmd" | $ir


LineSave=`$line | $ir`
#收集当前启动级别下已启动的服务,busybox没有chkconfig
echo "      [Started services]" | $ir
#收集chkconfig命令执行路径，busybox没有chkconfig
if [ -f $ChkCmd ] ; then

    #新版本使用chkconfig命令会有提示，将提示过滤
    ChkOn=`$ChkCmd 2>/dev/null | $by grep -E "$RunLevel:开|$RunLevel:on" | $ir`
    LineSave=`$line | $ir`

    #收集服务脚本内容
    ChkOnLine=`echo "$ChkOn" | wc -l`
    for ((n=1; n<=$ChkOnLine; n++))
    do
        ChkOnServerName=`echo "$ChkOn" | $by awk 'NR=='$n' {print $1}'`
        FileName="/etc/rc.d/init.d/$ChkOnServerName"
        echo "        [$FileName]" | $ir
        GetFileCon
    done
else
    echo "      [chkconfig cmdline]: not exist" | $ir
    echo "        [$ChkCmd]" | $ir
fi


#rc.local文件内容信息收集
LineSave=`$line | $ir`
echo "      [/etc/rc.d/rc.local]" | $ir
FileName="/etc/rc.d/rc.local"
GetFileCon




$line
#systemd服务信息收集
LineSave=`$line | $ir`
echo "    [2.3.2 Systemd]" | $ir

#确认systemctl执行路径
SystemctlCmd=`which systemctl`
echo "      [systemctl cmdline]: $SystemctlCmd" | $ir


#收集systemctl命令执行路径，busybox没有systemctl
if [ -f $SystemctlCmd ] ; then

    #收集已启动的服务
    echo "      [Started services]" | $ir
    SystemctlOn=`$SystemctlCmd list-unit-files --type service | $by grep -E "enabled|static" | $ir`


    #收集服务脚本内容
    SystemctlOnLine=`echo "$SystemctlOn" | wc -l`
    for ((i=1; i<=$SystemctlOnLine; i++))
    do
        SystemctlOnName1=`echo "$SystemctlOn" | $by awk 'NR=='$i' {print $1}'`

        #优先从/usr/lib/systemd/system/目录、收集Exec*=的值
        if [ -f /usr/lib/systemd/system/$SystemctlOnName1 ] ; then
            LineSave=`$line | $ir`
            echo "        [$SystemctlOnName1]" | $ir
            echo "          [/usr/lib/systemd/system/$SystemctlOnName1]" | $ir
            FilePathAll=`$by cat /usr/lib/systemd/system/$SystemctlOnName1 | $by grep "Exec" | $by awk -F "=" '{print $2}' | $by awk '{sub(/^-/,""); print}'  | $ir`
        
            #过滤Exec*=的值，只留下绝对路径，并去重
            FilePath=`echo "$FilePathAll" | $by awk -F " " '{print $1}' | $by sort | $by uniq`
            FilePathLine=`echo "$FilePath" | wc -l`

            #依次读取所有行的绝对路径，同时判断文件类型后放入GetFileType
            for ((a=1; a<=$FilePathLine; a++))
            do
                GetFilePathEcho=`echo "$FilePath" | $by awk 'NR=="'$a'" {print}'`
                FileType=`$FileCmd $GetFilePathEcho | $by awk -F ": " '{print $2}' | $by awk -F "," '{print $1}'`
                GetFileType
            done

        #如果判断1无法获取则从systemctl status中获取服务配置文件的绝对路径、因为部分服务通过本方法获取[Loaded：]中的绝对路径会提示该文件不存在，因此优先在判断1中提取，1中不存在时则通过判断2提取
        else
            SystemctlOnName2=`$SystemctlCmd status $SystemctlOnName1 | $by grep "Loaded:" | $by awk '{gsub(/\(/,"");gsub(/\;/,""); print $3}'`
            if [ -f $SystemctlOnName2 ] ; then
                LineSave=`$line | $ir`
                echo "        [$SystemctlOnName1]" | $ir
                echo "          [$SystemctlOnName2]" | $ir
                FilePathAll=`$by cat $SystemctlOnName2 | $by grep "Exec" | $by awk -F "=" '{print $2}' | $by awk '{sub(/^-/,""); print}'  | $ir`

                #过滤Exec*=的值，只留下绝对路径，并去重
                FilePath=`echo "$FilePathAll" | $by awk -F " " '{print $1}' | $by sort | $by uniq`
                FilePathLine=`echo "$FilePath" | wc -l`

                #依次读取所有行的绝对路径，同时判断文件类型后放入GetFileType
                for ((a=1; a<=$FilePathLine; a++))
                do
                    GetFilePathEcho=`echo "$FilePath" | $by awk 'NR=="'$a'" {print}'`
                    FileType=`$FileCmd $GetFilePathEcho | $by awk -F ": " '{print $2}' | $by awk -F "," '{print $1}'`
                    GetFileType
                done
            fi
        fi
    done
else
    echo "      [systemctl cmdline]: not exist" | $ir
    echo "        [$SystemctlCmd]" | $ir
fi




#2.4 账户权限
echo "    [2.4 Account authority]" | $ir
#收集可以登录的账户
if [ -f /etc/passwd ] ; then
    FileSum=`echo "/etc/passwd" >> $Temp2`
    AllAccount=`$by cat /etc/passwd | $by grep -vE ":/[a-z]+/nologin$|:/[a-z]+/shutdown$|:/[a-z]+/halt|:/[a-z]+/sync$" | $ir`
    LineSave=`$line | $ir`
fi


#收集该账户权限
AccountName=`echo "$AllAccount" | $by awk -F ":" '{print $1}'`
AccountHome=`echo "$AllAccount" | $by awk -F ":" '{print $(NF-1)}'`
AccountNameLine=`echo "$AccountName" | wc -l`
for ((i=1; i<=$AccountNameLine; i++))
do

    #收集账户的uid、gid、group信息
    AccountNameEcho=`echo "$AccountName" | $by awk 'NR=='$i' {print}'`
    echo "      [$AccountNameEcho id]" | $ir
    AccountId=`$by id $AccountNameEcho | $ir`

    #收集账户的公钥信息
    AccountHomeEcho=`echo "$AccountHome" | $by awk 'NR=='$i' {print}'`
    if [ -f $AccountHomeEcho\/.ssh/authorized_keys ] ; then
        FileSum=`echo "$AccountHomeEcho\/.ssh/authorized_keys" >> $Temp2`
        KeyName=`echo "      [$AccountHomeEcho/.ssh/authorized_keys]" | $ir`
        AuthorizedKey=`$by cat $AccountHomeEcho\/.ssh/authorized_keys | $ir`
    else
        KeyName=`echo "      [$AccountHomeEcho/.ssh/authorized_keys]" | $ir`
        FileNotExist=`echo "                                                 Not exist" | $ir`
    fi
    LineSave=`$line | $ir`
done



#2.5 rootkit
echo "    [2.5 Rootkit]" | $ir


#检查chkrootkit版本
ChkrootkitVerCheck(){

    #查看服务端和客户端的md5值
    echo "      [Chkrootkit version]" | $ir
    ChkDn=`$by nslookup ftp.pangeia.com.br 2>&1`
    DnsIp=`echo "$ChkDn" | $by awk -F ":" 'NR=="'1'" {gsub(/\t+/,""); print $2}'`
    ChkDnIp=`echo "$ChkDn" | $by grep -v "$DnsIp" | $by grep "Address" | $by awk -F ":" '{gsub(/ /,""); print $2}'`
    if [ "$ChkDnIp" = "" ] ; then
        ChkConSer=`echo "        Unable to connect ftp://ftp.pangeia.com.br/pub/seg/pac/chkrootkit.md5" | $ir`
        LineSave=`$line | $ir`
    else
        GetChkMd5File=`$by wget ftp://ftp.pangeia.com.br/pub/seg/pac/chkrootkit.md5 -O chkrootkit.md5 2>/dev/null`
        ChkMd5Ser=`$by cat chkrootkit.md5 | $by awk -F "  " '{print $1}'`
        ChkMd5Cli=`$by md5sum chkrootkit/chkrootkit.tar.gz | $by awk -F "  " '{print $1}'`

        #对比客户端和服务端版本是否一致
        if [ "$ChkMd5Cli" != "$ChkMd5Ser" ] ; then
            ChkEcho=`echo "        The local version of chkrootkit is not up to date,Please update yourself" | $ir`
            LineSave=`$line | $ir`
        else
            ChkEcho=`echo "        The local version of chkrootkit is up to date" | $ir`
            LineSave=`$line | $ir`
        fi
    fi

    #删除已下载的md5文件
    if [ -f chkrootkit.md5 ] ; then
        $by rm -rf chkrootkit.md5
    fi
}


#使用chkrootkit进行rootkit检查
ChkrootkitRun(){
    echo "      [Chkrootkit check results]" | $ir
    ChkRes=`$by sh chkrootkit/chkrootkit-0.54/chkrootkit 2>/dev/null | $by grep -vE "nothing found|not found|not infected|not tested|no suspect files|ROOTDIR" | $ir`
    FileSum=`echo "$ChkRes" | $by grep -oE "^/.*+" >> $Temp2`
    LineSave=`$line | $ir`
}


#判断是否需要进行rootkit检查，根据匹配内容进行对应的操作
read -ep "       Use chkrootkit to check rootkit. Chkrootkit is a third-party open source software. Need to check rootkit (y/n): " YesNo
for ((;;))
do
    YesNoMatch=`echo "$YesNo" | $by grep -E "^y$|^n$"`
    if [ "$YesNoMatch" = "y" ] ; then
        ChkrootkitVerCheck
        ChkrootkitRun
        break
    elif [ "$YesNoMatch" = "n" ] ; then
        LineSave=`$line | $ir`
        break
    else
        read -ep "       Use chkrootkit to check rootkit. Chkrootkit is a third-party open source software. Need to check rootkit (y/n): " YesNo
    fi
done




$line
#3 痕迹
echo "[3 Trace inspection]" | $ir
#3.1 登录日志
echo "  [3.1 Secure log]" | $ir


#登陆成功的记录
echo "    [Login successful]" | $ir
LoginS=`$by last | $ir`
LineSave=`$line | $ir`


#在线的账户
echo "    [Online account]" | $ir
OnlineA=`$by last | $by grep "logged in" | $ir`
LineSave=`$line | $ir`


#登陆失败汇总信息
echo "    [Login failed summary]" | $ir                                                                                        #排序去重，再按数量排序
LoginF=`$by grep "Failed password" /var/log/secure* | $by awk -F ":" '{$1=""; print}' | $by awk '{print $(NF-5),"\t",$(NF-3)}' | $by sort | $by uniq -c | $by sort -rn | $ir`
LineSave=`$line | $ir`


#具体的登陆失败事件
echo "    [Login failed time]" | $ir
LastCon=`$by grep "Failed password" /var/log/secure* | $by awk -F ":" '{$1=""; print}' | $by awk '{print $(NF-5),"\t",$(NF-3),"\t",$1,$2,"\t",$3,":",$4,":",$5}' | $ir`
LineSave=`$line | $ir`




#3.2 文件落地
echo "  [3.2 Document landing]" | $ir
echo "    [FileTime]" | $ir

#判断是否需要根据时间检查文件，根据匹配内容进行对应的操作
read -ep "      Is it necessary to check the documents according to the time(y/n): " YesNo
for ((;;))
do
    YesNoMatch=`echo "$YesNo" | $by grep -E "^y$|^n$"`
    if [ "$YesNoMatch" = "y" ] ; then
        getFileTime=`./getFileTime.sh | $ir`
        FileSum=`echo "$getFileTime" | $by grep -oE "^/.*+" >> $Temp2`
        LineSave=`$line | $ir`
        break
    elif [ "$YesNoMatch" = "n" ] ; then
        LineSave=`$line | $ir`
        break
    else
        read -ep "      Is it necessary to check the documents according to the time(y/n): " YesNo
    fi
done


#针对webshell进行检查
echo "    [Hm]" | $ir
#检查hm版本
HmVerCheck(){
    echo "    [Hm version]" | $ir
    HmVer=`hm/hm-linux-amd64/hm update | $ir`
    LineSave=`$line | $ir`
}


#使用Hm在指定的目录深度扫描WEBSHELL
HmRun(){
    read -ep "      Please enter the web directory(/paht1/path2/pathN): " WebPath
    for ((;;))
    do
        if [ "$WebPath" != "" ] && [[ -d $WebPath || -f $WebPath ]] ; then
            break
        else
            read -ep "      Please enter the web directory(/paht1/path2/pathN): " WebPath
        fi
    done 

    echo "    [Hm check results]" | $ir
    HmRes=`hm/hm-linux-amd64/hm deepscan $WebPath 2>/dev/null >> $Temp`
    FileSum=`echo "$HmRes" | $by awk -F "," '{print $NF}' | $by grep -oE "^/.*+" >> $Temp2`
    HmResSave=`$by cat $Temp | $by grep -E "^\+------|^\| 类型|^\| 后门|^\| 疑似|^\|          总计" | $ir`
    HmResEcho=`$by cat hm/hm-linux-amd64/result.csv | $by awk '{if (NR>1) print}' | $ir`
    LineSave=`$line | $ir`

    
    #删除cache.db，未联网状态下会在当前目录下生成
    if [ -f cache.db ] ; then
        $by rm -rf cache.db
    fi


    #删除临时文件
    if [ -f $Temp ] ; then
        $by rm -rf $Temp
    fi
}


#判断是否需要进行webshell检查，根据匹配内容进行对应的操作
read -ep "      Use Hm to check webshell.Hm is a third party software.Need to check webshell(y/n): " YesNo
for ((;;))
do
    YesNoMatch=`echo "$YesNo" | $by grep -E "^y$|^n$"`
    if [ "$YesNoMatch" = "y" ] ; then
        HmVerCheck
        HmRun
        break
    elif [ "$YesNoMatch" = "n" ] ; then
        LineSave=`$line | $ir`
        break
    else
        read -ep "      Use Hm to check webshell.Hm is a third party software.Need to check webshell(y/n): " YesNo
    fi
done




#3.3 历史命令
echo "  [3.3 History]" | $ir


#收集root账户bash的历史命令
echo "      [/root/.bash_history]" | $ir
    if [ -f /root/.bash_history ] ; then
	CatFile=`$by cat /root/.bash_history >> $HostIp-$SystemDate-results/2-root-history.txt`
        CatFileEcho=`echo "        Root history command saved to [$HostIp-$SystemDate-results/2-root-history.txt]"`
    else
        FileNotExist=`echo "                                                 Not exist" | $ir`
    fi


#收集普通账户bash的历史命令
for ((n=1; n<=$UserHomeLine; n++))
do
    UserHomeName=`echo "$UserHome" | $by awk 'NR=='$n' {print}'`
    FileName=`echo "/home/$UserHomeName/.bash_history"`
    LineSave=`$line | $ir`
    echo "      [$FileName]" | $ir
    if [ -f $FileName ] ; then
        CatFile=`$by cat $FileName >> $HostIp-$SystemDate-results/2-$UserHomeName-history.txt`
        CatFileEcho=`echo "        Root history command saved to [$HostIp-$SystemDate-results/2-$UserHomeName-history.txt]"`
    else
        FileNotExist=`echo "                                                 Not exist" | $ir`
    fi
done


#3.4 防火墙
echo "  [3.4 Firewall]" | $ir

echo "    [iptables]" | $ir
FileName="/etc/sysconfig/iptables"
FileSum=`echo "$FileName" >> $Temp2`
CatFileCon


LineSave=`$line | $ir`
echo "    [Firewalld]" | $ir
FileName="/etc/firewalld/zones/public.xml"
FileSum=`echo "$FileName" >> $Temp2`
CatFileCon




#将检查过的文件进行汇总信息记录，包括文件的类型、md5、访问时间、修改时间、状态时间
$line
echo "The checked files are being summarized and recorded"
GetFileSum


#将检查结果的md5生成并保存
echo "Generating and saving MD5 of check results to [$HostIp-$SystemDate-results/md5.txt]"
ReMd5=`$by md5sum $HostIp-$SystemDate-results/* >> $HostIp-$SystemDate-results/md5.txt`


#将检查结果打包，如需要可以删除注释
#$line
#echo "Packing check results"
#ReTar=`$by tar zcvf $HostIp-$SystemDate-results.tar.gz $HostIp-$SystemDate-results`
#$line
