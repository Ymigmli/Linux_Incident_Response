#!/bin/bash


#判断busybox是否存在，如不存在也不会影响脚本执行
if [ -f ./busybox ] ; then
    by="./busybox"
fi


line="echo -e \n-------------------------------------------------\n-------------------------------------------------"




#获取合法的绝对路径
PathNameCon(){
    read -ep "        Please enter the absolute path to match     (/path1/path2/pathN): " GetPathName
    for ((;;))
    do
        if [ "$GetPathName" != "" ] && [ -d $GetPathName ] ; then
            break
        else
            read -ep "        Please enter the absolute path to match     (/path1/path2/pathN): " GetPathName
        fi
    done
}




#获取不为空的关键字
KeyWordCon(){
    read -ep "        Please enter a keyword to match                     (* or *.php): " GetKeyWord
    for ((;;))
    do
        if [ "$GetKeyWord" != "" ] ; then
            break
        else
            read -ep "        Please enter a keyword to match                     (* or *.php): " GetKeyWord
        fi
    done
}




#获取开始时间，开始时间不可以比结束时间大（未作匹配，只注释说明）
StartTimeCon(){
    read -ep "        Please enter the start time                (2021-01-01 00:00:00): " StartTime
    for ((;;))
    do
        GetStartTime=`echo "$StartTime" | $by grep -E "^[0-9]{4}-[0-9]{2}-[0-9]{2}\s[0-9]{2}:[0-9]{2}:[0-9]{2}$"`
        if [ "$GetStartTime" != "" ] ; then
            break
        else
            read -ep "        Please enter the start time                (2021-01-01 00:00:00): " StartTime
        fi
    done
}




#获取结束时间
EndTimeCon(){
    read -ep "        Please enter the end time                  (2021-01-01 23:59:59): " EndTime
    for ((;;))
    do
        GetEndTime=`echo "$EndTime" | $by grep -E "^[0-9]{4}-[0-9]{2}-[0-9]{2}\s[0-9]{2}:[0-9]{2}:[0-9]{2}$"`
        if [ "$GetEndTime" != "" ] ; then
            break
        else
            read -ep "        Please enter the end time                  (2021-01-01 23:59:59): " EndTime
        fi
    done
}


#busybox的find不支持-newerXt
#需要注意的是newerat，newermt，newerct不会匹配起止时间，即“00:00:00”和“23:59:59”，但是区间时间“00:00:01~23:59:58”会被匹配。

#检查文件的Atime
GetFileAtime(){             #使用单引号包围$GetKeyWord的值并进行调用，将$GetStartTime、$GetEndTime的值当做一个整体，否则空格两边的内容会被拆分
    find $GetPathName -name "$GetKeyWord" -newerat "$GetStartTime" ! -newerat "$GetEndTime"
}


#检查文件的Mtime
GetFileMtime(){
    find $GetPathName -name "$GetKeyWord" -newermt "$GetStartTime" ! -newermt "$GetEndTime"
}


#检查文件的Ctime
GetFileCtime(){
    find $GetPathName -name "$GetKeyWord" -newerct "$GetStartTime" ! -newerct "$GetEndTime"
}




#将值排序去重
ConSummary(){
    PathNameCon
    KeyWordCon
    StartTimeCon
    EndTimeCon
    echo ""
    echo "    TimeType : $AMC"
    echo "    Path     : $GetPathName"
    echo "    KeyWord  : $GetKeyWord"
    echo "    StartTime: $GetStartTime"
    echo "    EndTime  : $GetEndTime"
    echo ""
    echo "    Matched  : "
    echo ""
}

GetA(){
    GetFileAtime
}


GetM(){
    GetFileMtime
}


GetC(){
    GetFileCtime
}


GetAM(){
    GetFileAtime
    GetFileMtime
}


GetAC(){
    GetFileAtime
    GetFileCtime
}


GetMC(){
    GetFileMtime
    GetFileCtime
}


GetAMC(){
    GetFileAtime
    GetFileMtime
    GetFileCtime
}




#根据给定的路径、关键字（如有）、开始时间、结束时间进行检查
read -ep "      What kind of (AMC)time do you need to check  (/a/m/c/am/ac/mc/amc): " AMC   #建议选择amc，因为会对重复的结果进行去重
for ((;;))
do
    GetAMC=`echo "$AMC" | $by grep -E "|a|m|c|am|ac|mc|amc"`
    if [ "$GetAMC" != "" ] ; then
        if [ "$GetAMC" = "a" ] ; then
            ConSummary
            GetA                                        | $by sort | $by uniq
            break
        elif [ "$GetAMC" = "m" ] ; then
            ConSummary
            GetM                                        | $by sort | $by uniq
            break
        elif [ "$GetAMC" = "c" ] ; then
            ConSummary
            GetC                                        | $by sort | $by uniq
            break
        elif [ "$GetAMC" = "am" ] ; then
            ConSummary
            GetAM                                       | $by sort | $by uniq
            break
        elif [ "$GetAMC" = "ac" ] ; then
            ConSummary
            GetAC                                       | $by sort | $by uniq
            break
        elif [ "$GetAMC" = "mc" ] ; then
            ConSummary
            GetMC                                       | $by sort | $by uniq
            break
        elif [ "$GetAMC" = "amc" ] ; then
            ConSummary
            GetAMC                                      | $by sort | $by uniq
            break
        else
            read -ep "      What kind of (AMC)time do you need to check  (/a/m/c/am/ac/mc/amc): " AMC
        fi
    else
        read -ep "      What kind of (AMC)time do you need to check  (/a/m/c/am/ac/mc/amc): " AMC
    fi
done
